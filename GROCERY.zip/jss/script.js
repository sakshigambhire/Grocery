let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () => 
{
   

   searchForm.classList.toggle('active');
   shoppingCart.classList.remove('active');
   loginForm.classList.remove('active');
   navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () => 
{
    
   searchForm.classList.remove('active');
   shoppingCart.classList.toggle('active');
   loginForm.classList.remove('active');
   navbar.classList.remove('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () => 
{
   searchForm.classList.remove('active');
   shoppingCart.classList.remove('active');
   loginForm.classList.toggle('active');
   navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () => 
{
   navbar.classList.toggle('active');
}



window.onscroll = () => 
{
   searchForm.classList.remove('active');
   shoppingCart.classList.remove('active');
   loginForm.classList.remove('active');
   navbar.classList.remove('active');
}



  var swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      spaceBetween: 10,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        "@0.00": {
          slidesPerView: 1,
          spaceBetween: 10,
        },
        "@0.75": {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        "@1.00": {
          slidesPerView: 3,
          spaceBetween: 40,
        },
        "@1.50": {
          slidesPerView: 4,
          spaceBetween: 50,
        },
      },
    });  var swiper = new Swiper(".product-slider", {
  loop: true,
  spaceBetween: 20,
  autoplay:
  {
   delay:7500,
   disableOnInteractions:false,
  },
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    750: {
      slidesPerView: 2,
    },
    1000: {
      slidesPerView: 3,
    },
    1500: {
      slidesPerView: 4,
    },
  },
});

var swiper = new Swiper(".review-slider", {
  loop: true,
  spaceBetween: 20,
  autoplay:
  {
   delay:2500,
   disableOnInteractions:false,
  },

  // Show slides depending on screen size
  breakpoints: {
    0: {
      slidesPerView: 1,   // Mobile
    },
    750: {
      slidesPerView: 2,   // Tablet
    },
    1000: {
      slidesPerView: 3,   // Desktop and bigger screens
    },
  },
});

